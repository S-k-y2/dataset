//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

function test0() {
    var func0 = function () {
        (function (loopInvariant) {
            eval('');
            while (
                {
                    prop0: uic8[loopInvariant + 1 & 1],
                    prop1: (undefined + 11) * Math.floor(--a) + 'method0'
                }
            )
            {
                if(4) {
                    break;
                }
                strvar1 = 2147483646;
                ({
                    prop2: 0,
                    prop3: undefined,
                    prop4: (3 & 255, 2)
                });
                continue;
                return 'somestring1';
                return 'somestring2';
            }
        }());
    };
    var uic8 = new Uint8ClampedArray();
    var a = 1;
    var temp = 0;
    do {
        func0();
    } while (temp++ < 4);
}
test0();
test0();
test0();

console.log("PASSED");
