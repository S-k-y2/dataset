//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

(function() {
var ary = new Array(10);
var obj0 = new Object();
var a;
var b;
var c;
var d;
var e;
var f;
var g;
var h;
a = 31991;
b = 4228;
c = -3781;
d = 45158;
e = 4467;
f = -60716;
g = 18044;
h = -23081;
obj0.a = 59929;
obj0.b = -920;
obj0.c = 61412;
obj0.d = 41979;
obj0.e = 40717;
ary[0] = -22552;
ary[1] = -61772;
ary[100] = -53104;
if(((20371 - ((obj0.c > -27035) ? obj0.e : (-37945 > -7637))) >= ((- (-37182 - 34770)) | ((obj0.b ^ h) | c)))) {
} else {
}
obj0.a = f;
a = 12028;
d = ((a & a) - (obj0.a * a));
WScript.Echo("a = " + (a>>3));
WScript.Echo("b = " + (b>>3));
WScript.Echo("c = " + (c>>3));
WScript.Echo("d = " + (d>>3));
WScript.Echo("e = " + (e>>3));
WScript.Echo("f = " + (f>>3));
WScript.Echo("g = " + (g>>3));
WScript.Echo("h = " + (h>>3));
WScript.Echo("obj0.a = " + (obj0.a>>3));
WScript.Echo("obj0.b = " + (obj0.b>>3));
WScript.Echo("obj0.c = " + (obj0.c>>3));
WScript.Echo("obj0.d = " + (obj0.d>>3));
WScript.Echo("obj0.e = " + (obj0.e>>3));
WScript.Echo("ary[0] = " + (ary[0]>>3));
WScript.Echo("ary[1] = " + (ary[1]>>3));
WScript.Echo("ary[100] = " + (ary[100]>>3));
WScript.Echo('done');
})();
