//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

(function() {
var ary = new Array(10);
var obj0 = new Object();
var a;
var b;
var c;
var d;
var e;
var f;
var g;
var h;
a = 63421;
b = 20591;
c = -1134;
d = 13268;
e = -24307;
f = 26328;
g = -29069;
h = -39599;
obj0.a = -29907;
obj0.b = 20646;
obj0.c = -57485;
obj0.d = 64158;
obj0.e = 31396;
ary[0] = -39303;
ary[1] = -51091;
ary[100] = -41642;
if(((((h == -14565) ? (18446 | 5505) : (++ obj0.e)) + d) < (d | (obj0.a | (e <= -11730))))) {
} else {
  if(((c * ((49147 ? c : -15090) & (obj0.e != 39791))) != (g - (obj0.a ^ (obj0.e ? 40237 : obj0.c))))) {
    obj0.e = obj0.b;
    if(((-38447 - f) >= (f & a))) {
      obj0.b = -38464;
      g = (((40800 | a) * ((-26812 * f) + (-10278 | a))) & (obj0.d - (d | -21044)));
      obj0.c = b;
    } else {
    }
    if(((-55344 * c) != (((38933 ? a : obj0.c) | (43496 & c)) - ((32441 != a) ? obj0.d : (obj0.c ? -57613 : obj0.d))))) {
      g = (+ (((b ^ obj0.c) <= (-10779 & 60317)) - ((g - obj0.e) * f)));
    } else {
      c = (obj0.a++ );
      obj0.a = obj0.d;
      g = c;
    }
  } else {
    h = (+ (c * ((-13138 - 56570) + (obj0.a + d))));
    if((((h + (c < c)) - h) == (h & (c > (obj0.d & -41174))))) {
      obj0.e = h;
      obj0.d = ((obj0.b | ((obj0.a | -29276) + (37757 ? obj0.d : g))) & (e + (f - a)));
      obj0.e = ((c - ((-23348 | 21451) == (-31862 - d))) - (((obj0.b * a) ^ (++ a)) ^ (- (obj0.e & 27751))));
    } else {
    }
  }
  b = c;
}
c = e;
if(((b + h) <= ((obj0.c ^ obj0.d) + 38512))) {
  f = (- (h + (f < obj0.c)));
  if(((d - ((obj0.a | 18387) - (42900 * f))) != (obj0.e + b))) {
  } else {
    c = a;
    a = ((g + (obj0.a | (62639 - 28737))) - ((obj0.e & (19220 | -943)) ^ ((b ^ -6362) * (obj0.b + obj0.b))));
    if(((((-290 > 10645) ? (e - c) : 53004) & ((- obj0.b) > g)) <= (((34790 + 33601) <= (-23137 ? -43709 : 2642)) & ((obj0.a - -54485) == g)))) {
      d = ((-21859 * ((-51513 ? -57792 : obj0.e) + (++ h))) < (obj0.e & 52596));
    } else {
      e = ((((27131 != -23790) ? (-43447 ^ g) : (-45730 + obj0.c)) - ((a > e) ? (-55948 * obj0.e) : (+ c))) ^ (f * h));
    }
  }
  if((((h & (3094 <= 23859)) * d) >= ((obj0.a++ ) + (obj0.e & (43702 + b))))) {
  } else {
  }
} else {
}
f = (((obj0.c ^ (d | -23005)) - e) - (((5839 ^ obj0.c) <= e) | (a++ )));
WScript.Echo("a = " + (a>>3));
WScript.Echo("b = " + (b>>3));
WScript.Echo("c = " + (c>>3));
WScript.Echo("d = " + (d>>3));
WScript.Echo("e = " + (e>>3));
WScript.Echo("f = " + (f>>3));
WScript.Echo("g = " + (g>>3));
WScript.Echo("h = " + (h>>3));
WScript.Echo("obj0.a = " + (obj0.a>>3));
WScript.Echo("obj0.b = " + (obj0.b>>3));
WScript.Echo("obj0.c = " + (obj0.c>>3));
WScript.Echo("obj0.d = " + (obj0.d>>3));
WScript.Echo("obj0.e = " + (obj0.e>>3));
WScript.Echo("ary[0] = " + (ary[0]>>3));
WScript.Echo("ary[1] = " + (ary[1]>>3));
WScript.Echo("ary[100] = " + (ary[100]>>3));
WScript.Echo('done');
})();
