//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

function test0() {
  var ui8 = new Uint8Array(1);
  try {
    try {
      for (var _strvar28 in ui8) {
        try {
          return '';
        } catch (ex) {
        }
        try {
        } catch (ex) {
        }
      }
   } catch(ex) {
   }
  } finally {
  }
}
test0();
test0();
test0();
test0();
print("Passed\n");
