//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

// -force:fieldhoist -prejit
(function(){
  var __loopvar0 = 0;
  LABEL0:
  do {
    __loopvar0++;
    if (d) {
    }
  } while (((++ obj9.d)) && __loopvar0 < 3)
})();
