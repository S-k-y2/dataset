//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------
try {
(function () {
  for (; 'caller' ? arrObj0[1364946552 >= 0 ? 1364946552 : 0] : 1766290373; ) {
    return 65535;
  }
}());
}
catch(ex) {
print("Passed");
}
