//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

WScript.Echo(RegExp().source);
WScript.Echo(RegExp().toString());
WScript.Echo( "1undefined2".split(undefined) );
