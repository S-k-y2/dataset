//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

var ary = Array();
var __loopvar0 = 8;
for (;;) {
  __loopvar0--;
  if (__loopvar0 == 1) {
    break;
  }
  ary[(typeof (825752278.1 && -229485894) != 'string') >= 0 ? typeof (825752278.1 && -229485894) : 0] = 214;
}
if (ary[0] != 214) {
  print("Passed")
}
