//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

(function() {
var ary = new Array(10);
var obj0 = new Object();
var a;
var b;
var c;
var d;
var e;
var f;
var g;
var h;
a = 17948;
b = -9798;
c = -41215;
d = -22786;
e = 61764;
f = -11528;
g = -42153;
h = -17941;
obj0.a = 47882;
obj0.b = 39195;
obj0.c = 17688;
obj0.d = 20292;
obj0.e = 62626;
ary[0] = -61785;
ary[1] = 29556;
ary[100] = -34231;
if((((+ (+ -13558)) - c) >= ((obj0.d + (obj0.e * obj0.c)) + b))) {
  if(((obj0.b | g) < ((++ obj0.e) & (obj0.a * (9189 <= 56450))))) {
  } else {
  }
  e = obj0.a;
  obj0.a = b;
} else {
  a = ((e ^ 41901) & ((! (d ? 28910 : g)) + ((obj0.c | c) & b)));
  if((((d & (-3887 | g)) | obj0.e) >= (d ^ ((d ^ -62581) * (obj0.b - obj0.a))))) {
    if((((+ (obj0.d + e)) & ((-51482 ? obj0.a : e) * (12741 & -22255))) >= (((obj0.a - -57330) + d) + (- e)))) {
      obj0.b = obj0.b;
    } else {
    }
    if(((((27130 ? obj0.a : obj0.d) & (f ^ obj0.b)) - g) == (-63771 * (+ (-32247 | obj0.b))))) {
    } else {
      b = (- (57356 * ((1670 * -34291) ^ 24289)));
      obj0.c = obj0.b;
      obj0.d = (f++ );
    }
    if(((obj0.a * ((obj0.d | -46468) + (19683 & -12533))) > (f + b))) {
    } else {
      b = f;
      obj0.e = a;
      d = a;
    }
  } else {
    obj0.c = ((((obj0.a != obj0.b) - (e - 55302)) & g) + (((-40378 <= b) <= d) ^ h));
  }
}
if(((7684 | ((-12784 | d) <= (f - -55467))) != (((47461 == obj0.d) + h) & b))) {
  obj0.a = h;
  c = ((-19737 * (35561 | c)) | ((++ c) * ((- obj0.c) < obj0.e)));
  if((((obj0.a & (+ obj0.a)) ^ ((-32490 - 50033) + obj0.b)) < (h & (+ (h | -56016))))) {
    if(((((f++ ) + (obj0.a + -1060)) ^ a) >= ((c + (e * obj0.c)) ^ 32732))) {
      d = ((((-24411 | 47542) != (b ? g : obj0.e)) ^ obj0.b) - (h | (obj0.e ^ (g ^ -15517))));
      obj0.e = ((f & (- (-61069 ^ 58846))) ^ (obj0.e | e));
      e = ((((obj0.a < obj0.b) ? (b <= d) : d) & ((63438 | 46480) & (c++ ))) ^ (d ^ (+ (31918 ? -16725 : obj0.c))));
    } else {
      a = obj0.c;
    }
    e = ((f & ((23461 + 53627) ^ c)) ? ((+ obj0.c) - ((++ obj0.b) * obj0.b)) : (obj0.d + obj0.d));
  } else {
    obj0.e = (((a < (-21586 & g)) * e) * (c + ((64880 * 43807) >= (56703 != obj0.c))));
    g = ((((-32973 ^ obj0.d) - (e * a)) ^ (-43540 - (-4992 & 42037))) ? (((obj0.c > -41228) ? 37666 : (37274 ? d : d)) & g) : (a | ((h <= 24207) ? (40792 & 7567) : (+ -41808))));
    c = 23786;
  }
} else {
  if(((obj0.d & ((1735 <= obj0.e) ? f : (-220 ? -39292 : 11307))) < (obj0.a - (f ^ (h > obj0.b))))) {
    if(((obj0.a ^ 35123) < (((f - g) >= (36366 | obj0.e)) | ((-11516 - -61153) != (-25241 | h))))) {
      g = ((((- h) | (- -25213)) - e) + (g * (a++ )));
      e = 19174;
    } else {
    }
    c = e;
    e = (! ((++ obj0.a) + g));
  } else {
    g = (((b + (a + a)) ^ (c & f)) ? (((14891 != f) ? (32836 * f) : (! -61613)) | -50664) : (obj0.b & (36542 - (26801 * -29464))));
    g = ((((- 52954) - (7704 * 23002)) + ((h & obj0.e) | obj0.a)) | ((+ (2608 & obj0.d)) | obj0.b));
    obj0.b = ((((e + -37183) < (+ obj0.d)) ^ c) ? ((12564 < obj0.e) + (a * (-24063 + 52389))) : ((h * (42773 - 20343)) | (+ (e - b))));
  }
  obj0.c = a;
}
c = a;
if((((-63466 | (5608 ? obj0.e : -31884)) ^ a) != (((-2534 + -16020) + (50582 ? obj0.c : e)) | ((-42446 <= e) ? obj0.b : c)))) {
  e = f;
  b = ((((b ^ 47956) & (g * e)) | ((g | 26836) & b)) * ((++ obj0.e) * obj0.c));
} else {
  if((((f + f) | h) != (((b + obj0.d) + (e + 60522)) & (-7417 ^ (d + 18663))))) {
    b = ((((33034 == h) ^ c) | ((-24730 + -64435) + (obj0.e | -233))) - (((++ obj0.a) + (obj0.b & obj0.b)) - ((47627 * obj0.e) * (- -2463))));
    g = ((d * (e & d)) | (obj0.d * (obj0.a | (-5373 - -25803))));
  } else {
    obj0.b = ((d + (- (4396 ? obj0.d : obj0.b))) | (((obj0.c ? -22126 : -44577) | (++ obj0.c)) | obj0.e));
    obj0.b = ((((obj0.d ? 56360 : obj0.b) + (60352 & 4975)) & ((g != -28744) ? (56818 & -45918) : (a ^ 49122))) ? (obj0.a | obj0.a) : (b + (! (! -32017))));
    e = obj0.b;
  }
}
WScript.Echo("a = " + (a>>3));
WScript.Echo("b = " + (b>>3));
WScript.Echo("c = " + (c>>3));
WScript.Echo("d = " + (d>>3));
WScript.Echo("e = " + (e>>3));
WScript.Echo("f = " + (f>>3));
WScript.Echo("g = " + (g>>3));
WScript.Echo("h = " + (h>>3));
WScript.Echo("obj0.a = " + (obj0.a>>3));
WScript.Echo("obj0.b = " + (obj0.b>>3));
WScript.Echo("obj0.c = " + (obj0.c>>3));
WScript.Echo("obj0.d = " + (obj0.d>>3));
WScript.Echo("obj0.e = " + (obj0.e>>3));
WScript.Echo("ary[0] = " + (ary[0]>>3));
WScript.Echo("ary[1] = " + (ary[1]>>3));
WScript.Echo("ary[100] = " + (ary[100]>>3));
WScript.Echo('done');
})();
