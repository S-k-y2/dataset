//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

(function() {
var ary = new Array(10);
var obj0 = new Object();
var a;
var b;
var c;
var d;
var e;
var f;
var g;
var h;
a = 55174;
b = -45304;
c = 46522;
d = -1927;
e = -61366;
f = 49542;
g = -43994;
h = -13997;
obj0.a = 43592;
obj0.b = 9352;
obj0.c = -44581;
obj0.d = 46853;
obj0.e = -51222;
ary[0] = -63393;
ary[1] = 35738;
ary[100] = -42571;
if(((g & ((14035 <= 27606) ^ (d & 29641))) == (((obj0.a < -7051) ? (f > 7646) : (obj0.a & 21702)) | ((46337 == -8265) ? a : (obj0.a * -3136))))) {
  g = h;
} else {
}
obj0.a = ((obj0.d ^ obj0.c) ^ (((d <= 14718) ? 5842 : c) * ((5335 * -40479) ^ (d * 63172))));
b = ((((-3947 <= 48539) ? e : obj0.c) - ((3117 * -5383) | (b + h))) - (e + -13679));
c = (((obj0.e & obj0.c) & h) * (obj0.b & obj0.c));
WScript.Echo("a = " + (a>>3));
WScript.Echo("b = " + (b>>3));
WScript.Echo("c = " + (c>>3));
WScript.Echo("d = " + (d>>3));
WScript.Echo("e = " + (e>>3));
WScript.Echo("f = " + (f>>3));
WScript.Echo("g = " + (g>>3));
WScript.Echo("h = " + (h>>3));
WScript.Echo("obj0.a = " + (obj0.a>>3));
WScript.Echo("obj0.b = " + (obj0.b>>3));
WScript.Echo("obj0.c = " + (obj0.c>>3));
WScript.Echo("obj0.d = " + (obj0.d>>3));
WScript.Echo("obj0.e = " + (obj0.e>>3));
WScript.Echo("ary[0] = " + (ary[0]>>3));
WScript.Echo("ary[1] = " + (ary[1]>>3));
WScript.Echo("ary[100] = " + (ary[100]>>3));
WScript.Echo('done');
})();
