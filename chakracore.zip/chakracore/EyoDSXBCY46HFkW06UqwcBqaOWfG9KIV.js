//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

(function() {
var ary = new Array(10);
var obj0 = new Object();
var a;
var b;
var c;
var d;
var e;
var f;
var g;
var h;
a = 1078;
b = -61609;
c = 59887;
d = -51644;
e = 63337;
f = 42816;
g = -43248;
h = -48176;
obj0.a = -63430;
obj0.b = 46853;
obj0.c = -46216;
obj0.d = 61084;
obj0.e = 6851;
ary[0] = -53479;
ary[1] = 27411;
ary[100] = -26255;
a = (((f | g) & (+ (57579 * -59934))) >= (h & ((-1761 <= d) ? obj0.b : (g ^ 58748))));
if(((((obj0.b == 4636) ? (10200 ^ obj0.e) : g) & -28083) == ((f * (45564 >= 56371)) + ((f - obj0.b) ^ (-64907 ? obj0.d : d))))) {
  obj0.a = (+ ((a++ ) - d));
} else {
  a = obj0.e;
}
a = ((((obj0.b - -12350) & (e * g)) ^ ((h != -50) ? (-7996 != 12764) : obj0.d)) * ((c - obj0.e) & (obj0.c | (13946 | -26296))));
obj0.e = (- (g + e));
WScript.Echo("a = " + (a>>3));
WScript.Echo("b = " + (b>>3));
WScript.Echo("c = " + (c>>3));
WScript.Echo("d = " + (d>>3));
WScript.Echo("e = " + (e>>3));
WScript.Echo("f = " + (f>>3));
WScript.Echo("g = " + (g>>3));
WScript.Echo("h = " + (h>>3));
WScript.Echo("obj0.a = " + (obj0.a>>3));
WScript.Echo("obj0.b = " + (obj0.b>>3));
WScript.Echo("obj0.c = " + (obj0.c>>3));
WScript.Echo("obj0.d = " + (obj0.d>>3));
WScript.Echo("obj0.e = " + (obj0.e>>3));
WScript.Echo("ary[0] = " + (ary[0]>>3));
WScript.Echo("ary[1] = " + (ary[1]>>3));
WScript.Echo("ary[100] = " + (ary[100]>>3));
WScript.Echo('done');
})();
