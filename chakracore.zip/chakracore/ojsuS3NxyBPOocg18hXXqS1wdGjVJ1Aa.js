//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

(function(){
    for (let a = 0, z =  "" ; a < 2; ++a) {
        z++;
        var z =function(){}
    }
    }
)();

