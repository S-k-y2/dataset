//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

(function() {
var ary = new Array(10);
var obj0 = new Object();
var a;
var b;
var c;
var d;
var e;
var f;
var g;
var h;
a = 46222;
b = -43784;
c = -5308;
d = -52896;
e = -14639;
f = -44125;
g = -45848;
h = -14459;
obj0.a = -15002;
obj0.b = -56620;
obj0.c = 1183;
obj0.d = -62632;
obj0.e = -30889;
ary[0] = 47805;
ary[1] = -11432;
ary[100] = -10000;
obj0.b = (((obj0.c + obj0.c) | ((-6010 == 31842) ? (g + f) : (g + 38228))) - ((obj0.e & (-10520 | c)) - (! (! -32237))));
if(((((-41256 != 31791) | e) & c) <= (((15449 ^ 1626) & (e * 25864)) - 35133))) {
  if((((h + (h | -10768)) - ((h + obj0.e) + (g + obj0.d))) <= ((62115 >= (37714 ? c : obj0.a)) & (+ d)))) {
    if(((((e < obj0.d) ? (obj0.d - 31967) : (-51336 & 35840)) * h) <= (h * a))) {
      b = 14508;
    } else {
      b = h;
      a = obj0.e;
      obj0.a = g;
    }
    h = g;
    if((((h + h) * (a != h)) >= (e ^ ((obj0.c == f) ? (-43229 ? -62923 : c) : (-12473 ? -50330 : obj0.e))))) {
      obj0.d = (((a > (d >= 32019)) + e) - (((-42148 + 58334) ^ (33902 + obj0.a)) & (31517 ^ -64319)));
    } else {
    }
  } else {
    if((((d * b) * ((-4216 ? -14011 : f) | -60159)) >= (((obj0.d ? 36634 : obj0.a) * (22013 ^ h)) & ((h > f) ? (! h) : b)))) {
    } else {
    }
    if((((obj0.d > (-50770 ^ -38145)) | ((-40440 == 37089) & (e * b))) != (-27956 & -24646))) {
      d = ((((obj0.a == d) ? (g & -60884) : b) + h) | (((7500 != 1936) | (56581 ? b : 8823)) - (obj0.e | (a ? 23953 : h))));
    } else {
      a = a;
    }
  }
  e = ((((g + obj0.c) == (b - 37699)) & (h | e)) >= ((- (1428 * -58733)) * ((obj0.c >= 28662) ? (-19343 | d) : (-24127 - obj0.a))));
} else {
  b = (! (e ^ (63244 + g)));
}
if(((obj0.b ^ ((28718 & a) >= (-34349 - f))) != (-2688 | (++ g)))) {
  obj0.a = obj0.b;
  h = 45667;
} else {
  h = e;
}
obj0.c = f;
WScript.Echo("a = " + (a>>3));
WScript.Echo("b = " + (b>>3));
WScript.Echo("c = " + (c>>3));
WScript.Echo("d = " + (d>>3));
WScript.Echo("e = " + (e>>3));
WScript.Echo("f = " + (f>>3));
WScript.Echo("g = " + (g>>3));
WScript.Echo("h = " + (h>>3));
WScript.Echo("obj0.a = " + (obj0.a>>3));
WScript.Echo("obj0.b = " + (obj0.b>>3));
WScript.Echo("obj0.c = " + (obj0.c>>3));
WScript.Echo("obj0.d = " + (obj0.d>>3));
WScript.Echo("obj0.e = " + (obj0.e>>3));
WScript.Echo("ary[0] = " + (ary[0]>>3));
WScript.Echo("ary[1] = " + (ary[1]>>3));
WScript.Echo("ary[100] = " + (ary[100]>>3));
WScript.Echo('done');
})();
