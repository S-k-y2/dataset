//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

(function() {
var ary = new Array(10);
var obj0 = new Object();
var a;
var b;
var c;
var d;
var e;
var f;
var g;
var h;
a = 44810;
b = 660;
c = 54229;
d = -13798;
e = -1346;
f = -54300;
g = 6969;
h = 12883;
obj0.a = -53787;
obj0.b = -58392;
obj0.c = -62424;
obj0.d = -47894;
obj0.e = -55553;
ary[0] = -59206;
ary[1] = 22759;
ary[100] = 8366;
if(((h ^ ((-34176 & 23693) & (-6132 & a))) <= ((obj0.b | (obj0.e | -3973)) ^ (d >= (-24056 ? obj0.c : d))))) {
  d = ((c + 55126) - ((! obj0.c) - ((-49876 >= 43021) ? (obj0.c | -36074) : (21816 ^ -9475))));
  g = 18987;
} else {
  if(((((a == -51083) ? obj0.a : obj0.c) & h) != (f - (obj0.b ^ (c | -11910))))) {
    if(((((f * -7690) - (a ^ b)) ^ b) > (((54904 < g) ? (+ f) : (obj0.d * obj0.d)) + obj0.b))) {
      g = (((obj0.d - (++ obj0.d)) ^ (d & obj0.c)) | (f ^ c));
      obj0.d = e;
    } else {
    }
  } else {
  }
}
obj0.e = ((f - (obj0.c != (61214 & d))) & (((-17760 | f) ^ (obj0.d ? 49851 : 22990)) | (! (-44764 ? d : a))));
b = obj0.b;
f = obj0.d;
WScript.Echo("a = " + (a>>3));
WScript.Echo("b = " + (b>>3));
WScript.Echo("c = " + (c>>3));
WScript.Echo("d = " + (d>>3));
WScript.Echo("e = " + (e>>3));
WScript.Echo("f = " + (f>>3));
WScript.Echo("g = " + (g>>3));
WScript.Echo("h = " + (h>>3));
WScript.Echo("obj0.a = " + (obj0.a>>3));
WScript.Echo("obj0.b = " + (obj0.b>>3));
WScript.Echo("obj0.c = " + (obj0.c>>3));
WScript.Echo("obj0.d = " + (obj0.d>>3));
WScript.Echo("obj0.e = " + (obj0.e>>3));
WScript.Echo("ary[0] = " + (ary[0]>>3));
WScript.Echo("ary[1] = " + (ary[1]>>3));
WScript.Echo("ary[100] = " + (ary[100]>>3));
WScript.Echo('done');
})();
