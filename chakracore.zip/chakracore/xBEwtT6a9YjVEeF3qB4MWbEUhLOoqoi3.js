//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

var a = [];
for (var i = 0; i < 1; ++i) {
    for (var j = 0; j < 1; ++j) {
        a[i] = Math.sin(j - 1);

    }
    const xx = 34;
    WScript.Echo(xx);
}

  