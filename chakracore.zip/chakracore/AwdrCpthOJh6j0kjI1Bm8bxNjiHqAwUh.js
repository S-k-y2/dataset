//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

(function() {
var ary = new Array(10);
var obj0 = new Object();
var a;
var b;
var c;
var d;
var e;
var f;
var g;
var h;
a = -32836;
b = -63958;
c = -33154;
d = -9263;
e = -57368;
f = 19474;
g = -64676;
h = -45870;
obj0.a = -28503;
obj0.b = -44448;
obj0.c = -52987;
obj0.d = 10842;
obj0.e = 59310;
ary[0] = 43477;
ary[1] = 30920;
ary[100] = -41992;
if(((((g - 51622) == obj0.b) * (b ^ f)) >= (d & ((d != 36656) ? (++ g) : (! g))))) {
  obj0.b = ((h | obj0.d) | ((-3134 + (-44126 - obj0.c)) | (+ (+ -34699))));
  obj0.a = ((b * ((62692 | 52370) - (h + obj0.b))) ^ (g * ((-707 | e) & -29064)));
  h = ((d * c) | (e ^ (g | (! obj0.e))));
} else {
  a = (! (obj0.e & obj0.a));
  obj0.a = 34622;
}
if(((((-22478 ? e : c) + (-52674 ^ 65213)) - obj0.a) > ((! obj0.a) + c))) {
  h = (((++ f) * (h != (-45651 & -49671))) + ((obj0.d < e) | obj0.d));
  f = (((f - (52419 & 62546)) - obj0.d) * (e * obj0.a));
} else {
}
if(((((! b) - obj0.b) & ((obj0.b ^ 12809) | obj0.a)) > (obj0.e - (obj0.a | 3432)))) {
  f = ((f + d) - (((-39593 >= obj0.c) - (obj0.e + 56127)) - (obj0.d & obj0.c)));
} else {
  f = e;
}
c = ((((-21133 | -53102) - (-21518 - obj0.a)) + (obj0.a < e)) - ((f & obj0.e) ^ 8432));
WScript.Echo("a = " + (a>>3));
WScript.Echo("b = " + (b>>3));
WScript.Echo("c = " + (c>>3));
WScript.Echo("d = " + (d>>3));
WScript.Echo("e = " + (e>>3));
WScript.Echo("f = " + (f>>3));
WScript.Echo("g = " + (g>>3));
WScript.Echo("h = " + (h>>3));
WScript.Echo("obj0.a = " + (obj0.a>>3));
WScript.Echo("obj0.b = " + (obj0.b>>3));
WScript.Echo("obj0.c = " + (obj0.c>>3));
WScript.Echo("obj0.d = " + (obj0.d>>3));
WScript.Echo("obj0.e = " + (obj0.e>>3));
WScript.Echo("ary[0] = " + (ary[0]>>3));
WScript.Echo("ary[1] = " + (ary[1]>>3));
WScript.Echo("ary[100] = " + (ary[100]>>3));
WScript.Echo('done');
})();
