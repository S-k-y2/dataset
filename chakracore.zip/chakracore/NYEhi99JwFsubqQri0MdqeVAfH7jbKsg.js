//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

﻿if ('퓛'.localeCompare('\u1111\u1171\u11B6') != 0) { print(54491); }
print('PASS');