//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

function shapeyConstructor() {
    y = iczqcn;
}
for (var w in [1,2]) {
    try {
        new shapeyConstructor(w);
    } catch (e) {
    }
}
let iczqcn = undefined;

WScript.Echo("PASS");

