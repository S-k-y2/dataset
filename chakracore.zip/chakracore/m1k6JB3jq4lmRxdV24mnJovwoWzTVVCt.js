//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

(function() {
var ary = new Array(10);
var obj0 = new Object();
var a;
var b;
var c;
var d;
var e;
var f;
var g;
var h;
a = 60638;
b = 15500;
c = -18662;
d = -15973;
e = 54322;
f = -37818;
g = 26834;
h = -57251;
obj0.a = -53072;
obj0.b = 39379;
obj0.c = 54079;
obj0.d = -23222;
obj0.e = -42250;
ary[0] = 15142;
ary[1] = 32569;
ary[100] = -50287;
if(((obj0.c | 15550) <= (f ^ (e + obj0.a)))) {
  if(((c - (g <= b)) < (((c | obj0.b) * obj0.b) * obj0.e))) {
    a = ((((55590 + -46499) ^ (c <= h)) - (-5932 & e)) + (h * obj0.a));
    if(((g * -48863) == (g ^ (f++ )))) {
    } else {
      e = -537;
      obj0.c = ((obj0.b + ((-2475 & d) >= (38715 == f))) * (((-47185 ^ -12771) < (obj0.d | -52153)) - h));
    }
  } else {
  }
  if(((((b | obj0.d) + (g * f)) ^ (! b)) >= (e & (+ obj0.c)))) {
    if(((obj0.a ^ ((g + -7623) + (31042 ? e : c))) > (obj0.d * (62169 & (b & obj0.c))))) {
    } else {
      h = -62350;
      c = ((obj0.b - -33799) & (h & h));
      obj0.a = -29950;
    }
    obj0.e = (((- (-7846 >= -8722)) | ((-21864 ? e : -30839) + e)) ? ((d * (h ^ f)) + obj0.e) : (((49956 ^ 21226) * (c >= 48337)) ^ -28495));
    h = b;
  } else {
    if(((8521 & (! (b ^ h))) != (((d >= -39641) ? e : (obj0.a - e)) & (33154 - (obj0.b & -49266))))) {
    } else {
      a = a;
    }
  }
  if(((c * (+ obj0.a)) < (a - ((-47473 ? c : obj0.c) >= (-64174 - obj0.c))))) {
  } else {
  }
} else {
  f = (((b - (obj0.c & 46394)) - (e & obj0.e)) ? (((a * -37620) + (-26144 - c)) | f) : (((+ 11329) > (25851 | 5550)) + e));
}
d = ((obj0.c | h) | (((16482 | -42279) > b) + (g ^ f)));
if(((35616 + ((f & c) + (60327 & obj0.e))) >= (c - obj0.a))) {
  if((((obj0.c & obj0.c) ^ ((-2130 ? c : -22144) + (37204 - obj0.e))) == (((! c) ^ c) & (b ^ 36871)))) {
    f = f;
    if(((((-1678 == h) ? (f >= 26595) : (-333 - 18438)) ^ obj0.c) >= (obj0.b - ((-22048 == 12160) & (a + -28384))))) {
      h = obj0.e;
      obj0.a = ((((g ? obj0.b : obj0.a) + (b - 44932)) | obj0.a) | ((c | (26977 < obj0.e)) + a));
    } else {
      b = a;
    }
  } else {
    obj0.e = ((((a - a) != (e < g)) | ((-3212 != -2708) ? (obj0.d++ ) : e)) ^ ((c + (obj0.b ? -35593 : -40374)) + (+ (-40412 ? b : obj0.c))));
    c = obj0.b;
    b = ((obj0.c + (! -16440)) < (obj0.b & (a & obj0.b)));
  }
} else {
  if((((+ obj0.d) - (+ d)) > (19714 * ((d * obj0.a) ^ (obj0.e++ ))))) {
  } else {
  }
  if(((((65501 + f) != d) + b) > (b * ((-42798 <= -46251) * obj0.b)))) {
    e = (! (obj0.c | ((obj0.e ? -30276 : f) | (g | -47864))));
    if(((((3378 != obj0.e) ? obj0.c : e) & obj0.c) >= (((52361 == h) ? e : obj0.d) ^ ((17375 >= g) | f)))) {
    } else {
      obj0.b = ((((d != e) != 33414) ^ (+ (! -47798))) - ((obj0.a - h) | (+ (obj0.d ^ h))));
      d = (((obj0.a ^ (f - c)) ^ (f + (52463 ^ f))) ^ ((obj0.e * (++ obj0.c)) | ((-11901 + c) | e)));
      e = (((obj0.b != -40232) + h) * ((g | (65483 + 15591)) | ((31978 ^ g) - (-8487 == -28093))));
    }
  } else {
    if((((+ 17259) & ((h ? -48177 : -37880) * c)) >= (f & (obj0.a ^ (49945 ? d : d))))) {
    } else {
      obj0.b = (a++ );
      a = ((obj0.a ^ 18205) | ((e - (obj0.a + e)) * ((e > g) * (+ 40443))));
    }
    if((((a * (h * -21047)) ^ -27460) < (obj0.c + (c & (63221 * b))))) {
      obj0.c = (e++ );
      f = ((((-60999 | 63233) - d) - 64312) ^ ((d ^ obj0.c) * obj0.a));
      obj0.b = 6276;
    } else {
      d = (! (((obj0.a > -44572) != (b ? obj0.c : -710)) - ((obj0.e > -7595) ? obj0.d : (obj0.d != 40931))));
    }
  }
  if(((d + c) <= (obj0.b * ((obj0.b ? 60429 : -43706) * -60289)))) {
  } else {
    if((((! obj0.c) * ((c | e) * (d++ ))) <= (c * ((obj0.d ^ -30609) & (25824 <= -41161))))) {
      obj0.d = 36178;
    } else {
      obj0.a = 7623;
    }
  }
}
e = ((((8543 != -9268) ? obj0.b : (-60718 ^ -60373)) & c) - (((-12558 <= obj0.a) ^ -672) ^ (h | obj0.d)));
WScript.Echo("a = " + (a>>3));
WScript.Echo("b = " + (b>>3));
WScript.Echo("c = " + (c>>3));
WScript.Echo("d = " + (d>>3));
WScript.Echo("e = " + (e>>3));
WScript.Echo("f = " + (f>>3));
WScript.Echo("g = " + (g>>3));
WScript.Echo("h = " + (h>>3));
WScript.Echo("obj0.a = " + (obj0.a>>3));
WScript.Echo("obj0.b = " + (obj0.b>>3));
WScript.Echo("obj0.c = " + (obj0.c>>3));
WScript.Echo("obj0.d = " + (obj0.d>>3));
WScript.Echo("obj0.e = " + (obj0.e>>3));
WScript.Echo("ary[0] = " + (ary[0]>>3));
WScript.Echo("ary[1] = " + (ary[1]>>3));
WScript.Echo("ary[100] = " + (ary[100]>>3));
WScript.Echo('done');
})();
