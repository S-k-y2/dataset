//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

function test0() {
    function leaf() {
    }
    var obj1 = {};
    var func0 = function () {
        WScript.Echo(a);
    };
    var func2 = function (argMath0) {
        var __loopvar2 = 5;
        for (; a < (argMath0 >>>= test0) ; a++) {
            __loopvar2 += 2;
            if (__loopvar2 >= 5 + 6) {
                break;
            }
        }
        func0();
        return 65535;
    };
    obj1.method1 = func2;
    var IntArr1 = [
      -198980986,
      476677656118063740
    ];
    var a = 2147483647;
    var __loopvar0 = 5;
    do {
        __loopvar0 += 4;
        if (__loopvar0 == 5 + 16) {
            break;
        }
    } while (obj1.method1((IntArr1.pop())));
}
test0();
test0();
