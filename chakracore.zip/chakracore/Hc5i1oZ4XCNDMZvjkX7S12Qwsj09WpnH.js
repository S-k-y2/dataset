//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

(function() {
var ary = new Array(10);
var obj0 = new Object();
var a;
var b;
var c;
var d;
var e;
var f;
var g;
var h;
a = -41037;
b = -12268;
c = 30451;
d = -44187;
e = 40781;
f = -44018;
g = 45859;
h = 61181;
obj0.a = 41006;
obj0.b = -36826;
obj0.c = 46401;
obj0.d = -28026;
obj0.e = 62568;
ary[0] = -3016;
ary[1] = 35431;
ary[100] = -44796;
if(((b ^ ((4467 | obj0.a) != h)) <= (((-48473 | g) <= (obj0.b + -32561)) & (+ (50134 & d))))) {
} else {
  if(((obj0.c ^ d) == (((53319 - obj0.c) & (obj0.b == g)) | obj0.b))) {
    obj0.d = 31951;
    obj0.c = obj0.d;
    a = a;
  } else {
    obj0.b = ((h - h) | (obj0.a ^ ((54581 ^ obj0.e) != obj0.d)));
    g = b;
  }
  f = 19497;
}
e = h;
b = g;
obj0.b = (((obj0.b >= (obj0.e ? obj0.a : -59904)) + h) - (((obj0.d - 37426) - (-55087 + -31178)) * ((obj0.e ^ obj0.c) | (f & obj0.b))));
WScript.Echo("a = " + (a>>3));
WScript.Echo("b = " + (b>>3));
WScript.Echo("c = " + (c>>3));
WScript.Echo("d = " + (d>>3));
WScript.Echo("e = " + (e>>3));
WScript.Echo("f = " + (f>>3));
WScript.Echo("g = " + (g>>3));
WScript.Echo("h = " + (h>>3));
WScript.Echo("obj0.a = " + (obj0.a>>3));
WScript.Echo("obj0.b = " + (obj0.b>>3));
WScript.Echo("obj0.c = " + (obj0.c>>3));
WScript.Echo("obj0.d = " + (obj0.d>>3));
WScript.Echo("obj0.e = " + (obj0.e>>3));
WScript.Echo("ary[0] = " + (ary[0]>>3));
WScript.Echo("ary[1] = " + (ary[1]>>3));
WScript.Echo("ary[100] = " + (ary[100]>>3));
WScript.Echo('done');
})();
