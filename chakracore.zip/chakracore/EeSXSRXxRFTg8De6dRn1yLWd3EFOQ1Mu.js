//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

(function() {
var ary = new Array(10);
var obj0 = new Object();
var a;
var b;
var c;
var d;
var e;
var f;
var g;
var h;
a = 53258;
b = 19364;
c = -55022;
d = -13104;
e = -47840;
f = -54781;
g = 28153;
h = 37472;
obj0.a = 54344;
obj0.b = 21716;
obj0.c = 32985;
obj0.d = -7258;
obj0.e = 35306;
ary[0] = 64302;
ary[1] = -59632;
ary[100] = 26397;
if(((((-40712 | g) ^ (obj0.e + f)) | obj0.d) < (b - d))) {
  obj0.a = (+ (((a * -408) ^ (b & e)) + obj0.b));
} else {
}
d = ((((24255 | -3463) ^ (-1459 | obj0.c)) - (h | e)) - (46299 * (- (-36766 ^ b))));
obj0.c = ((a ^ (obj0.b - (e * obj0.b))) - (b ^ ((-35434 * 15269) ^ (b - obj0.d))));
if(((b - (-46007 & -36586)) > (obj0.a ^ ((-24370 ? -44143 : -13250) + (h > -44413))))) {
} else {
  if((((53928 + e) | ((obj0.b | -55334) > (24431 * -47395))) > (((50152 | h) | -34357) | ((-5122 < obj0.b) ? b : (h ^ 46571))))) {
    obj0.e = obj0.a;
  } else {
    if(((((-37949 + -43603) > (-45137 <= h)) - (d + (-42928 ? g : f))) == (((-53872 ^ b) + (g - -62521)) ^ (- (51333 ^ -15535))))) {
    } else {
      g = d;
      obj0.e = b;
      b = -15179;
    }
    obj0.e = obj0.a;
  }
  obj0.a = obj0.b;
}
WScript.Echo("a = " + (a>>3));
WScript.Echo("b = " + (b>>3));
WScript.Echo("c = " + (c>>3));
WScript.Echo("d = " + (d>>3));
WScript.Echo("e = " + (e>>3));
WScript.Echo("f = " + (f>>3));
WScript.Echo("g = " + (g>>3));
WScript.Echo("h = " + (h>>3));
WScript.Echo("obj0.a = " + (obj0.a>>3));
WScript.Echo("obj0.b = " + (obj0.b>>3));
WScript.Echo("obj0.c = " + (obj0.c>>3));
WScript.Echo("obj0.d = " + (obj0.d>>3));
WScript.Echo("obj0.e = " + (obj0.e>>3));
WScript.Echo("ary[0] = " + (ary[0]>>3));
WScript.Echo("ary[1] = " + (ary[1]>>3));
WScript.Echo("ary[100] = " + (ary[100]>>3));
WScript.Echo('done');
})();
