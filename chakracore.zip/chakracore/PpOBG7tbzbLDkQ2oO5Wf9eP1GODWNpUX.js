//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

function test0() {
    var GiantPrintArray = [];
    var obj0 = {};
    var protoObj0 = {};
    var protoObj1 = {};
    var obj2 = {};
    var protoObj2 = {};
    var func0 = function () {
        if ({} instanceof EvalError ^ (parseInt()) * (ary - protoObj2.prop6)) {
            var uniqobj1 = uniqobj0;
        } else {
            protoObj0.prop4 = uic8;
            ({ b: { n: protoObj1.prop0 } });
            for (var v0 = 0; v0 < 3; v0++) {
                protoObj1.prop4 = protoObj1.prop1 === protoObj1 && obj2 === protoObj1.prop6;
            }
        }
        GiantPrintArray.push(protoObj1.prop5);
    };
    var func1 = function () {
        (function () {
            Math.sin(new func0()) ? -(argMath10 * -921543659 - -1139958822.9) : prop4 = ui16;
            func0(func0());
        }(new func0()));
    };
    var func3 = function () {
        var uniqobj6 = { 33: func1((new func0())) };
    };
    obj0.method0 = func3;
    method1 = obj0.method0;
    var ui16 = new Uint16Array();
    var uic8 = new Uint8ClampedArray();
    var VarArr0 = Array();
    ary = 856134889;
    protoObj0.prop0 = 194709012;
    protoObj0.prop1 = -377120002;
    protoObj0.prop2 = -1996023131.9;
    protoObj0.prop3 = 114;
    protoObj1.prop0 = -3;
    protoObj1.prop1 = -1824894349.9;
    protoObj1.prop2 = 1469720302881920000;
    protoObj1.prop3 = -1231853442;
    protoObj1.prop4 = -563681667;
    protoObj1.prop5 = 1;
    protoObj2.prop6 = -7120587829494880000;
    method1(typeof (--protoObj2.prop6 >= (VarArr0[false ? VarArr0[17] = 'x' : undefined, 17] instanceof (typeof Object == 'function' ? Object : Object))));
}
test0();

WScript.Echo('pass');