//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

function test0() {
  var ui16 = new Uint16Array();
    for (var _strvar0 in ui16) {
      litObj1.prop0 = ui16.length;
      if (litObj1.prop0.prop0) {
        ui16.length;
      }
    }
}

test0();
test0();
test0();
WScript.Echo("PASSED");

