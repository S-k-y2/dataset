//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

(function() {
var ary = new Array(10);
var obj0 = new Object();
var a;
var b;
var c;
var d;
var e;
var f;
var g;
var h;
a = 9451;
b = -53830;
c = -10117;
d = -24122;
e = 40416;
f = -40379;
g = 27373;
h = -51473;
obj0.a = 48100;
obj0.b = 56861;
obj0.c = 21716;
obj0.d = 48846;
obj0.e = 30015;
ary[0] = -4998;
ary[1] = -56593;
ary[100] = 36899;
d = 2718;
if((((obj0.d + obj0.d) & b) > ((+ (61531 | g)) | (+ (obj0.a++ ))))) {
  e = -63715;
  g = h;
} else {
}
if(((((-17643 ^ 54009) - (! -59183)) - h) != (e + c))) {
  if((((- h) ^ b) == (obj0.a ^ (obj0.a & g)))) {
    b = ((f ^ 37635) | (((a + obj0.c) >= e) & -4763));
    if((((+ (obj0.e | 8036)) | ((-41462 - a) > (32235 ? obj0.e : -45740))) >= (40622 & (h & obj0.e)))) {
      a = ((((- 55896) | (64808 ? 50006 : 42731)) - obj0.b) * ((d + (-53489 * 22792)) & ((d ^ a) | h)));
    } else {
    }
    if(((obj0.b ^ ((obj0.d != e) == (b | obj0.a))) == (obj0.e ^ ((obj0.b == -29104) ? b : obj0.c)))) {
    } else {
    }
  } else {
  }
  d = a;
} else {
  obj0.b = f;
  f = (((obj0.c * (obj0.a * obj0.e)) ^ ((++ c) <= obj0.e)) + (e ^ ((f ? obj0.a : b) ^ a)));
  f = ((h ^ 33693) < (((obj0.b++ ) * obj0.d) * (b == f)));
}
if(((((37482 - e) | (+ 32933)) - -41957) > (((obj0.b + 55244) ^ e) - obj0.c))) {
  if((((+ h) & ((g + -42230) ^ obj0.d)) >= ((h++ ) + obj0.b))) {
    obj0.e = d;
    if(((obj0.a & ((254 | f) | c)) < (e ^ a))) {
      obj0.b = obj0.b;
      h = 3279;
    } else {
      b = obj0.c;
      g = ((((g ? -15749 : 49805) * (+ a)) * obj0.c) * (((h <= -32957) ? obj0.c : (43015 ? c : c)) | (obj0.c ^ f)));
      d = -30894;
    }
    if(((((+ 59940) - (! b)) * d) < ((obj0.e + (-44630 * -58986)) - (obj0.e & obj0.c)))) {
      obj0.a = (((obj0.a++ ) & (obj0.b | b)) + (e * obj0.c));
      f = obj0.e;
    } else {
    }
  } else {
  }
} else {
  a = 31816;
}
WScript.Echo("a = " + (a>>3));
WScript.Echo("b = " + (b>>3));
WScript.Echo("c = " + (c>>3));
WScript.Echo("d = " + (d>>3));
WScript.Echo("e = " + (e>>3));
WScript.Echo("f = " + (f>>3));
WScript.Echo("g = " + (g>>3));
WScript.Echo("h = " + (h>>3));
WScript.Echo("obj0.a = " + (obj0.a>>3));
WScript.Echo("obj0.b = " + (obj0.b>>3));
WScript.Echo("obj0.c = " + (obj0.c>>3));
WScript.Echo("obj0.d = " + (obj0.d>>3));
WScript.Echo("obj0.e = " + (obj0.e>>3));
WScript.Echo("ary[0] = " + (ary[0]>>3));
WScript.Echo("ary[1] = " + (ary[1]>>3));
WScript.Echo("ary[100] = " + (ary[100]>>3));
WScript.Echo('done');
})();
