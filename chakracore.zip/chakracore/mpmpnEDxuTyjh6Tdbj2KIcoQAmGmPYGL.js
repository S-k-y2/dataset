"use strict";

WScript.LoadScriptFile("symbols.js");
WScript.LoadScriptFile("tmp_base.js");
WScript.LoadScriptFile("arg.js");
WScript.LoadScriptFile("basic_block.js");
WScript.LoadScriptFile("code.js");
WScript.LoadScriptFile("frequented_block.js");
WScript.LoadScriptFile("inst.js");
WScript.LoadScriptFile("opcode.js");
WScript.LoadScriptFile("reg.js");
WScript.LoadScriptFile("stack_slot.js");
WScript.LoadScriptFile("tmp.js");
WScript.LoadScriptFile("util.js");
WScript.LoadScriptFile("custom.js");
WScript.LoadScriptFile("liveness.js");
WScript.LoadScriptFile("insertion_set.js");
WScript.LoadScriptFile("allocate_stack.js");
