//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

(function() {
var ary = new Array(10);
var obj0 = new Object();
var a;
var b;
var c;
var d;
var e;
var f;
var g;
var h;
a = -28368;
b = 42911;
c = -50391;
d = -14996;
e = -23944;
f = -12446;
g = -4817;
h = -12250;
obj0.a = -19014;
obj0.b = 60514;
obj0.c = 47591;
obj0.d = 10400;
obj0.e = 22566;
ary[0] = -48253;
ary[1] = 15503;
ary[100] = 38122;
if(((((g < f) ^ obj0.b) * ((! obj0.e) - (a - obj0.a))) <= (obj0.d + f))) {
  if(((((obj0.c < f) ? -64731 : b) - (obj0.c - (obj0.d | 44294))) != (((f + obj0.b) * (-43978 == -23017)) + (obj0.d - (50641 == 44362))))) {
  } else {
  }
} else {
}
obj0.e = ((g + c) * (obj0.e - ((obj0.b + obj0.b) + -4469)));
c = ((((obj0.d != -16268) ? (-46344 ? obj0.c : g) : (63310 ^ c)) ^ obj0.d) - (d | (! (-19485 - f))));
if((((++ obj0.d) ^ (e + (64982 ^ -15054))) > (((obj0.c + obj0.a) - -33412) - c))) {
  if(((((obj0.e & -46979) - obj0.d) ^ (obj0.c != (obj0.b * 64751))) < ((g | c) & (obj0.d & (-23336 ^ obj0.e))))) {
    if(((((15293 + e) * (1114 ^ obj0.d)) - ((-17141 != 35528) | g)) > (((27640 > 54872) ? c : obj0.e) * ((-45300 ^ obj0.d) * c)))) {
      c = ((((b >= -55403) ? (h ? -56256 : 24391) : obj0.a) - b) + ((obj0.e - (d ^ -24391)) ^ ((e != 42043) ? (-22159 + -43965) : (31763 > d))));
    } else {
      b = ((h & (42532 != (obj0.b * -53435))) != (((b - -10895) ^ h) * (h + (obj0.a & 17433))));
      e = (obj0.a++ );
      obj0.b = c;
    }
  } else {
    obj0.b = (((b + (obj0.a - e)) + g) | (((- obj0.e) - (++ a)) ^ ((40430 == -50161) <= (obj0.e - f))));
    if((((d ^ obj0.b) + -13692) < (1245 ^ g))) {
    } else {
      c = ((((f * 52539) ^ g) * (obj0.a | (-26288 ^ obj0.c))) - (d ^ (g & (obj0.e * -18001))));
      obj0.b = ((e * obj0.b) - (a * (+ a)));
    }
    obj0.e = ((((23611 > d) ? (obj0.b | a) : 36935) + c) | (g * obj0.c));
  }
  if(((obj0.b - ((49468 ? d : -12628) + -515)) != (a ^ a))) {
    a = (((+ (c + f)) | (obj0.d >= (d | a))) | ((+ (21891 * e)) & ((b | -27114) != (35361 ^ f))));
  } else {
    e = ((((48614 ? obj0.c : 62810) * obj0.c) * ((b * h) ^ (16092 - obj0.b))) > (((a++ ) - (g * e)) - ((obj0.c > -47669) * (65107 & -1697))));
    if(((d - (obj0.b * (++ obj0.a))) <= (obj0.c | (obj0.e + (-5719 * -42289))))) {
      obj0.e = ((((! h) <= (-24680 & 44371)) - -35456) + ((c + (c ? obj0.b : obj0.a)) & obj0.a));
      obj0.b = obj0.e;
      obj0.d = 64854;
    } else {
    }
    if((((++ c) + obj0.a) > (21745 | d))) {
      f = obj0.c;
    } else {
      g = ((b ^ -46797) ? ((obj0.e * (e <= obj0.e)) - ((obj0.c == a) - obj0.a)) : (obj0.c + obj0.c));
      c = obj0.e;
    }
  }
  if(((obj0.a & f) < (obj0.b & ((-23310 + g) >= (b + e))))) {
    f = a;
  } else {
    if(((55885 + a) < (b + ((15739 >= obj0.c) * -10761)))) {
      f = ((((2362 & -59241) <= (c < obj0.c)) ^ obj0.a) & (e ^ obj0.a));
      b = ((f + a) * ((obj0.c | e) + (b ^ (61290 * obj0.c))));
      d = (++ h);
    } else {
      g = 37860;
    }
  }
} else {
  if((((! (47429 * obj0.c)) + ((51453 & 16610) | (-23423 | obj0.b))) >= ((obj0.b - h) ^ ((-61512 > 34253) ? (obj0.a * -5859) : obj0.b)))) {
    h = (((f++ ) * a) ? ((- a) * (obj0.d & (+ -2))) : (c | ((c | h) + (-43019 & -41186))));
    obj0.d = ((((++ e) + obj0.d) * ((obj0.d + b) ^ f)) ? ((f - (-60617 ? -34862 : h)) - obj0.b) : (((-13815 >= -29810) ? h : d) ^ ((-52852 <= 18158) ? h : (-38253 ^ 57474))));
    if(((26194 - c) == ((f & obj0.d) ^ h))) {
      c = obj0.c;
    } else {
      obj0.e = (((62032 + 34666) - ((57589 <= -128) ? (- h) : obj0.c)) - (-26508 ^ (f - (obj0.d * -22941))));
      g = obj0.a;
    }
  } else {
    if(((e - b) == (obj0.c + (h ^ f)))) {
    } else {
      f = obj0.a;
    }
  }
  g = ((obj0.e | ((-62976 * 53818) * a)) & ((obj0.d * (53695 * -54609)) - (obj0.e++ )));
  if((((d * 9798) * obj0.b) <= (-8180 + (h * obj0.c)))) {
  } else {
    h = a;
  }
}
WScript.Echo("a = " + (a>>3));
WScript.Echo("b = " + (b>>3));
WScript.Echo("c = " + (c>>3));
WScript.Echo("d = " + (d>>3));
WScript.Echo("e = " + (e>>3));
WScript.Echo("f = " + (f>>3));
WScript.Echo("g = " + (g>>3));
WScript.Echo("h = " + (h>>3));
WScript.Echo("obj0.a = " + (obj0.a>>3));
WScript.Echo("obj0.b = " + (obj0.b>>3));
WScript.Echo("obj0.c = " + (obj0.c>>3));
WScript.Echo("obj0.d = " + (obj0.d>>3));
WScript.Echo("obj0.e = " + (obj0.e>>3));
WScript.Echo("ary[0] = " + (ary[0]>>3));
WScript.Echo("ary[1] = " + (ary[1]>>3));
WScript.Echo("ary[100] = " + (ary[100]>>3));
WScript.Echo('done');
})();
