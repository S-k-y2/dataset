//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE.txt file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

// use -forcejitloopbody
var i = 0;
var obj0 = {};
var obj1 = {};
var VarArr0 = new Array();
obj1.PROP0 = 5;
VarArr0;
do {
    while (obj0) {
        VarArr0[0] = 1; 

        obj0.length = 0;
        obj0.PROP0 = 'substring';
        obj0.PROP0.substring(1,2);

        switch (obj0.PROP0) { 
            case 's1':
            case 's2':
            case 's3':
            case 's4':
        }

        var __loopvar4 = 0;
        for (; obj1.PROP0 < 1; __loopvar4) {
        }

        if (i++ === 1) {
            break;
        }
    }
} while (false);

WScript.Echo(obj0.PROP0);
WScript.Echo(obj1.PROP0);